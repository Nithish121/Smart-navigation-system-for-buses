from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator
from typing import List, Optional
import uvicorn
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Vehicle Plate Scanner API",
    description="API for managing bus data and processing vehicle plates",
    version="1.0.0",
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Data Models
class Bus(BaseModel):
    id: Optional[int] = None
    busName: str = Field(..., example="Bus A")
    numberPlate: str = Field(..., example="TN59EQ0001")
    from_city: str = Field(..., example="City A")
    to_city: str = Field(..., example="City B")
    platformNumber: str = Field(..., example="1")
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @validator('numberPlate')
    def plate_must_be_alphanumeric(cls, v):
        if not v.isalnum():
            raise ValueError('numberPlate must be alphanumeric')
        return v

class PlateData(BaseModel):
    plate: str = Field(..., example="TN59EQ0001")

# In-memory storage (replace with a database in production)
buses: List[Bus] = []
next_bus_id = 1

@app.get("/")
async def root():
    return {"message": "Vehicle Plate Scanner API"}

@app.post("/api/buses", response_model=Bus, status_code=status.HTTP_201_CREATED)
async def add_bus(bus: Bus):
    global next_bus_id
    # Check for duplicate number plate
    for existing_bus in buses:
        if existing_bus.numberPlate == bus.numberPlate:
            raise HTTPException(status_code=400, detail="Bus with this number plate already exists")
    bus.id = next_bus_id
    bus.created_at = datetime.utcnow()
    bus.updated_at = datetime.utcnow()
    next_bus_id += 1
    buses.append(bus)
    logger.info(f"Added bus: {bus}")
    return bus

@app.get("/api/buses", response_model=List[Bus])
async def get_buses():
    return buses

@app.get("/api/buses/{bus_id}", response_model=Bus)
async def get_bus(bus_id: int):
    for bus in buses:
        if bus.id == bus_id:
            return bus
    raise HTTPException(status_code=404, detail="Bus not found")

@app.put("/api/buses/{bus_id}", response_model=Bus)
async def update_bus(bus_id: int, updated_bus: Bus):
    for index, bus in enumerate(buses):
        if bus.id == bus_id:
            updated_data = updated_bus.dict(exclude_unset=True)
            # Prevent updating the bus ID
            updated_data.pop("id", None)
            updated_data["updated_at"] = datetime.utcnow()
            buses[index] = bus.copy(update=updated_data)
            logger.info(f"Updated bus {bus_id}: {buses[index]}")
            return buses[index]
    raise HTTPException(status_code=404, detail="Bus not found")

@app.delete("/api/buses/{bus_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_bus(bus_id: int):
    global buses
    for bus in buses:
        if bus.id == bus_id:
            buses.remove(bus)
            logger.info(f"Deleted bus {bus_id}")
            return
    raise HTTPException(status_code=404, detail="Bus not found")

@app.post("/api/plates")
async def process_plate(plate_data: PlateData):
    try:
        # Here you would normally store/process plate data in a database.
        logger.info(f"Processing plate: {plate_data.plate} at {datetime.utcnow()}")
        return {"message": f"Plate {plate_data.plate} processed successfully"}
    except Exception as e:
        logger.error("Error processing plate", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/plates/{plate}", response_model=Bus)
async def get_plate_info(plate: str):
    # Return the first bus matching the provided plate
    for bus in buses:
        if bus.numberPlate == plate:
            return bus
    raise HTTPException(status_code=404, detail="Plate not found")

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
