import os
import shutil
import hashlib
from datetime import datetime, timedelta
from typing import Optional

import jwt
import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr

# JWT settings (update secret in production)
JWT_SECRET = "YOUR_SECRET_KEY"
JWT_ALGORITHM = "HS256"
JWT_EXP_DELTA_SECONDS = 3600

app = FastAPI()

# Allow CORS for local testing (adjust in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (HTML, CSS, JS, images)
app.mount("/", StaticFiles(directory="static", html=True), name="static")

# In-memory "database" for demonstration purposes
fake_db = {}

# Directory to store uploaded profile photos
UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

# Helper to hash passwords (for demo only; use a secure algorithm in production)
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Helper to create a JWT token
def create_jwt_token(email: str) -> str:
    payload = {
        "email": email,
        "exp": datetime.utcnow() + timedelta(seconds=JWT_EXP_DELTA_SECONDS)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token

# Pydantic models for login endpoints
class LoginData(BaseModel):
    email: EmailStr
    password: str

class GoogleLoginData(BaseModel):
    credential: str

# OAuth2 scheme that expects the token in the Authorization header using the Bearer schema
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/login")

# Dependency to get the current user based on the JWT token
def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        email = payload.get("email")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        user = fake_db.get(email)
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")

# Registration endpoint: expects form-data (including optional file upload)
@app.post("/api/register")
async def register(
    fullName: str = Form(...),
    email: EmailStr = Form(...),
    phone: str = Form(...),
    password: str = Form(...),
    dob: str = Form(...),
    state: str = Form(...),
    profilePhoto: Optional[UploadFile] = File(None)
):
    # Check if user is already registered
    if email in fake_db:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Save the profile photo file if provided
    photo_filename = None
    if profilePhoto:
        photo_filename = f"{email.replace('@', '_at_')}_{profilePhoto.filename}"
        file_path = os.path.join(UPLOAD_DIR, photo_filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(profilePhoto.file, buffer)

    # Hash the password before saving it
    hashed_password = hash_password(password)

    # Create a new user record
    user = {
        "fullName": fullName,
        "email": email,
        "phone": phone,
        "password": hashed_password,
        "dob": dob,
        "state": state,
        "profilePhoto": photo_filename
    }
    fake_db[email] = user

    return {"message": "Registration successful"}

# Login endpoint: expects JSON data with email and password
@app.post("/api/login")
async def login(data: LoginData):
    user = fake_db.get(data.email)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    if hash_password(data.password) != user["password"]:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    # Generate and return a JWT token
    token = create_jwt_token(data.email)
    return {"token": token}

# Google login endpoint: simulates Google login
@app.post("/api/google-login")
async def google_login(data: GoogleLoginData):
    credential = data.credential
    if not credential:
        raise HTTPException(status_code=400, detail="Invalid Google credential")

    # In production, verify the token with Google's API.
    # For demonstration, we try to decode it (without verifying signature)
    try:
        decoded = jwt.decode(credential, options={"verify_signature": False})
        email = decoded.get("email")
    except Exception:
        # Fallback: use the credential value as email (for demo purposes)
        email = credential

    if not email:
        raise HTTPException(status_code=400, detail="Invalid Google credential")

    # Auto-register the user if not already in the database
    if email not in fake_db:
        user = {
            "fullName": "Google User",
            "email": email,
            "phone": "",
            "password": "",  # No password required when using Google login
            "dob": "",
            "state": "",
            "profilePhoto": ""
        }
        fake_db[email] = user

    token = create_jwt_token(email)
    return {"token": token}

# A sample protected endpoint that requires a valid JWT token
@app.get("/api/protected")
async def protected_route(current_user: dict = Depends(get_current_user)):
    return {"message": f"Hello, {current_user['fullName']}! This is a protected route."}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
import os
import shutil
import hashlib
from datetime import datetime, timedelta
from typing import Optional

import jwt
import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr

# JWT settings (update secret in production)
JWT_SECRET = "YOUR_SECRET_KEY"
JWT_ALGORITHM = "HS256"
JWT_EXP_DELTA_SECONDS = 3600

app = FastAPI()

# Allow CORS for local testing (adjust in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (HTML, CSS, JS, images)
app.mount("/", StaticFiles(directory="static", html=True), name="static")

# In-memory "database" for demonstration purposes
fake_db = {}

# Directory to store uploaded profile photos
UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

# Helper to hash passwords (for demo only; use a secure algorithm in production)
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Helper to create a JWT token
def create_jwt_token(email: str) -> str:
    payload = {
        "email": email,
        "exp": datetime.utcnow() + timedelta(seconds=JWT_EXP_DELTA_SECONDS)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token

# Pydantic models for login endpoints
class LoginData(BaseModel):
    email: EmailStr
    password: str

class GoogleLoginData(BaseModel):
    credential: str

# OAuth2 scheme that expects the token in the Authorization header using the Bearer schema
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/login")

# Dependency to get the current user based on the JWT token
def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        email = payload.get("email")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        user = fake_db.get(email)
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")

# Registration endpoint: expects form-data (including optional file upload)
@app.post("/api/register")
async def register(
    fullName: str = Form(...),
    email: EmailStr = Form(...),
    phone: str = Form(...),
    password: str = Form(...),
    dob: str = Form(...),
    state: str = Form(...),
    profilePhoto: Optional[UploadFile] = File(None)
):
    # Check if user is already registered
    if email in fake_db:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Save the profile photo file if provided
    photo_filename = None
    if profilePhoto:
        photo_filename = f"{email.replace('@', '_at_')}_{profilePhoto.filename}"
        file_path = os.path.join(UPLOAD_DIR, photo_filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(profilePhoto.file, buffer)

    # Hash the password before saving it
    hashed_password = hash_password(password)

    # Create a new user record
    user = {
        "fullName": fullName,
        "email": email,
        "phone": phone,
        "password": hashed_password,
        "dob": dob,
        "state": state,
        "profilePhoto": photo_filename
    }
    fake_db[email] = user

    return {"message": "Registration successful"}

# Login endpoint: expects JSON data with email and password
@app.post("/api/login")
async def login(data: LoginData):
    user = fake_db.get(data.email)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    if hash_password(data.password) != user["password"]:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    # Generate and return a JWT token
    token = create_jwt_token(data.email)
    return {"token": token}

# Google login endpoint: simulates Google login
@app.post("/api/google-login")
async def google_login(data: GoogleLoginData):
    credential = data.credential
    if not credential:
        raise HTTPException(status_code=400, detail="Invalid Google credential")

    # In production, verify the token with Google's API.
    # For demonstration, we try to decode it (without verifying signature)
    try:
        decoded = jwt.decode(credential, options={"verify_signature": False})
        email = decoded.get("email")
    except Exception:
        # Fallback: use the credential value as email (for demo purposes)
        email = credential

    if not email:
        raise HTTPException(status_code=400, detail="Invalid Google credential")

    # Auto-register the user if not already in the database
    if email not in fake_db:
        user = {
            "fullName": "Google User",
            "email": email,
            "phone": "",
            "password": "",  # No password required when using Google login
            "dob": "",
            "state": "",
            "profilePhoto": ""
        }
        fake_db[email] = user

    token = create_jwt_token(email)
    return {"token": token}

# A sample protected endpoint that requires a valid JWT token
@app.get("/api/protected")
async def protected_route(current_user: dict = Depends(get_current_user)):
    return {"message": f"Hello, {current_user['fullName']}! This is a protected route."}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
