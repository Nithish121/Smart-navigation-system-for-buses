import os
import datetime
import logging
from functools import wraps
from typing import Dict, Any

from flask import Flask, request, jsonify, send_from_directory, Blueprint
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import jwt
import bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URI', 'sqlite:///vehicles.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit
    JSONIFY_PRETTYPRINT_REGULAR = True

# ------------------------------------------------------------------
# Logging Configuration
# ------------------------------------------------------------------
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Ensure the upload folder exists
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

# ------------------------------------------------------------------
# Flask App Setup
# ------------------------------------------------------------------
app = Flask(__name__)
app.config.from_object(Config)
CORS(app, resources={r"/api/*": {"origins": "*"}})
db = SQLAlchemy(app)

# Initialize rate limiter
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"])

# Create a Blueprint for API endpoints
api_bp = Blueprint('api', __name__, url_prefix='/api')

# ------------------------------------------------------------------
# Models
# ------------------------------------------------------------------
class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bus_name = db.Column(db.String(100), nullable=False)
    number_plate = db.Column(db.String(20), nullable=False)
    from_location = db.Column(db.String(100), nullable=False)
    to_location = db.Column(db.String(100), nullable=False)
    platform_number = db.Column(db.String(50), nullable=False)
    bus_stand = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# ------------------------------------------------------------------
# Static Data for States and Bus Stand Details
# ------------------------------------------------------------------
stateData = {
    "tamil_nadu": {
        "districts": {
            "chennai": {"busStands": ["Chennai Mofussil Bus Terminus (CMBT)", "Koyambedu Bus Stand"]},
            "coimbatore": {"busStands": ["Gandhipuram Central Bus Stand", "Ukkadam Bus Stand"]},
            "madurai": {"busStands": ["Mattuthavani Bus Stand", "Periyar Bus Stand"]},
            "salem": {"busStands": ["Salem Central Bus Stand"]},
            "trichy": {"busStands": ["Central Bus Stand", "Chathiram Bus Stand"]}
        }
    },
    "kerala": {
        "districts": {
            "thiruvananthapuram": {"busStands": ["Thampanoor Bus Stand"]},
            "kochi": {"busStands": ["Vyttila Mobility Hub", "Ernakulam KSRTC Bus Stand"]},
            "calicut": {"busStands": ["Moffusil Bus Stand"]},
            "kollam": {"busStands": ["Kollam KSRTC Bus Stand"]}
        }
    },
    "karnataka": {
        "districts": {
            "bangalore": {"busStands": ["Kempegowda Bus Station", "Shantinagar Bus Stand"]},
            "mysore": {"busStands": ["Mysore City Bus Stand"]},
            "mangalore": {"busStands": ["State Bank Bus Stand"]},
            "hubli": {"busStands": ["Old Bus Stand"]}
        }
    }
}

busStandDetails = {
    "Chennai Mofussil Bus Terminus (CMBT)": {
        "address": "Koyambedu, Chennai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Chennai+Mofussil+Bus+Terminus"
    },
    "Koyambedu Bus Stand": {
        "address": "Koyambedu, Chennai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Koyambedu+Bus+Stand"
    },
    "Gandhipuram Central Bus Stand": {
        "address": "Gandhipuram, Coimbatore, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Gandhipuram+Central+Bus+Stand"
    },
    "Ukkadam Bus Stand": {
        "address": "Ukkadam, Coimbatore, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Ukkadam+Bus+Stand"
    },
    "Mattuthavani Bus Stand": {
        "address": "Mattuthavani, Madurai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Mattuthavani+Bus+Stand"
    },
    "Periyar Bus Stand": {
        "address": "Periyar, Madurai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Periyar+Bus+Stand"
    },
    "Salem Central Bus Stand": {
        "address": "Salem, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Salem+Central+Bus+Stand"
    },
    "Central Bus Stand": {
        "address": "Trichy, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Central+Bus+Stand+Trichy"
    },
    "Chathiram Bus Stand": {
        "address": "Trichy, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Chathiram+Bus+Stand+Trichy"
    },
    "Thampanoor Bus Stand": {
        "address": "Thampanoor, Thiruvananthapuram, Kerala, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Thampanoor+Bus+Stand"
    },
    "Vyttila Mobility Hub": {
        "address": "Vyttila, Kochi, Kerala, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Vyttila+Mobility+Hub"
    },
    "Ernakulam KSRTC Bus Stand": {
        "address": "Ernakulam, Kochi, Kerala, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Ernakulam+KSRTC+Bus+Stand"
    },
    "Moffusil Bus Stand": {
        "address": "Calicut, Kerala, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Moffusil+Bus+Stand+Calicut"
    },
    "Kollam KSRTC Bus Stand": {
        "address": "Kollam, Kerala, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Kollam+KSRTC+Bus+Stand"
    },
    "Kempegowda Bus Station": {
        "address": "Majestic, Bangalore, Karnataka, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Kempegowda+Bus+Station"
    },
    "Shantinagar Bus Stand": {
        "address": "Shantinagar, Bangalore, Karnataka, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Shantinagar+Bus+Stand"
    },
    "Mysore City Bus Stand": {
        "address": "Mysore, Karnataka, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Mysore+City+Bus+Stand"
    },
    "State Bank Bus Stand": {
        "address": "Mangalore, Karnataka, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=State+Bank+Bus+Stand+Mangalore"
    },
    "Old Bus Stand": {
        "address": "Hubli, Karnataka, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Old+Bus+Stand+Hubli"
    }
}

# ------------------------------------------------------------------
# Helper Functions for Vehicles
# ------------------------------------------------------------------
def vehicle_to_dict(vehicle: Vehicle) -> Dict[str, Any]:
    return {
        'id': vehicle.id,
        'busName': vehicle.bus_name,
        'numberPlate': vehicle.number_plate,
        'from': vehicle.from_location,
        'to': vehicle.to_location,
        'platformNumber': vehicle.platform_number,
        'busStand': vehicle.bus_stand,
        'createdAt': vehicle.created_at.isoformat()
    }

# ------------------------------------------------------------------
# API Endpoints
# ------------------------------------------------------------------

# Endpoint: Get list of vehicles (with optional bus stand filtering)
@api_bp.route('/vehicles', methods=['GET'])
@limiter.limit("20 per minute")
def get_vehicles():
    try:
        bus_stand_filter = request.args.get('busStand', None)
        query = Vehicle.query
        if bus_stand_filter:
            query = query.filter(Vehicle.bus_stand == bus_stand_filter)
        vehicles = query.order_by(Vehicle.created_at.desc()).all()
        return jsonify({'vehicles': [vehicle_to_dict(v) for v in vehicles]}), 200
    except Exception as e:
        logger.exception("Error retrieving vehicles: %s", e)
        return jsonify({'error': f'Error retrieving vehicles: {str(e)}'}), 500

# Endpoint: Create a new vehicle entry
@api_bp.route('/vehicles', methods=['POST'])
@limiter.limit("10 per minute")
def add_vehicle():
    try:
        data = request.get_json(silent=True) or {}
        required_fields = ['busName', 'numberPlate', 'from', 'to', 'platformNumber', 'busStand']
        missing = [field for field in required_fields if not data.get(field)]
        if missing:
            msg = f"Missing required fields: {', '.join(missing)}"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        new_vehicle = Vehicle(
            bus_name=data.get('busName'),
            number_plate=data.get('numberPlate'),
            from_location=data.get('from'),
            to_location=data.get('to'),
            platform_number=data.get('platformNumber'),
            bus_stand=data.get('busStand')
        )
        db.session.add(new_vehicle)
        db.session.commit()
        logger.info(f"New vehicle added: {new_vehicle.number_plate}")
        return jsonify({'message': 'Vehicle added successfully', 'vehicle': vehicle_to_dict(new_vehicle)}), 201

    except Exception as e:
        db.session.rollback()
        logger.exception("Error adding vehicle: %s", e)
        return jsonify({'error': f'Error adding vehicle: {str(e)}'}), 500

# Endpoint: Get a single vehicle by ID
@api_bp.route('/vehicles/<int:vehicle_id>', methods=['GET'])
@limiter.limit("20 per minute")
def get_vehicle(vehicle_id):
    try:
        vehicle = Vehicle.query.get(vehicle_id)
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        return jsonify({'vehicle': vehicle_to_dict(vehicle)}), 200
    except Exception as e:
        logger.exception("Error retrieving vehicle: %s", e)
        return jsonify({'error': f'Error retrieving vehicle: {str(e)}'}), 500

# Endpoint: Get state/district data
@api_bp.route('/states', methods=['GET'])
def get_states():
    try:
        return jsonify({'states': stateData}), 200
    except Exception as e:
        logger.exception("Error retrieving states data: %s", e)
        return jsonify({'error': f'Error retrieving states data: {str(e)}'}), 500

# Endpoint: Get bus stand details by name (via query parameter)
@api_bp.route('/bus-stand-details', methods=['GET'])
def get_bus_stand_details():
    try:
        bus_stand_name = request.args.get('name', None)
        if not bus_stand_name:
            return jsonify({'error': 'Bus stand name not provided'}), 400
        details = busStandDetails.get(bus_stand_name)
        if not details:
            return jsonify({'error': 'Bus stand details not found'}), 404
        return jsonify({'busStandDetails': details}), 200
    except Exception as e:
        logger.exception("Error retrieving bus stand details: %s", e)
        return jsonify({'error': f'Error retrieving bus stand details: {str(e)}'}), 500

# Endpoint: Serve uploaded files (profile photos, etc.)
@api_bp.route('/uploads/<filename>')
def uploaded_file(filename):
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    except Exception as e:
        logger.exception("Error serving file: %s", e)
        return jsonify({'error': f'Error serving file: {str(e)}'}), 500

# ------------------------------------------------------------------
# Register Blueprint and Initialize DB
# ------------------------------------------------------------------
app.register_blueprint(api_bp)

def init_db():
    with app.app_context():
        db.create_all()
        logger.info("Database initialized")

# Global error handler for unhandled exceptions
@app.errorhandler(Exception)
def handle_exception(e):
    logger.exception("Unhandled exception: %s", e)
    return jsonify({'error': f'An internal error occurred: {str(e)}'}), 500

# ------------------------------------------------------------------
# Run Application
# ------------------------------------------------------------------
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8000, debug=True)
