from flask import Flask, request, jsonify
import json
import os
import threading
import logging
from flask_cors import CORS
import re
from PIL import Image
import io
import base64

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Path to store the plate data
PLATE_DATA_FILE = os.getenv('PLATE_DATA_FILE', 'plates.json')
file_lock = threading.Lock()

# Ensure the data file exists
if not os.path.exists(PLATE_DATA_FILE):
    with open(PLATE_DATA_FILE, 'w') as file:
        json.dump([], file)

def is_valid_plate(plate: str) -> bool:
    """
    Validate the plate format: alphanumeric, length between 1 and 10.
    Leading and trailing whitespace is ignored and input is converted to uppercase.
    """
    if not isinstance(plate, str):
        return False
    plate = plate.strip().upper()
    return bool(re.match(r'^[A-Z0-9]{1,10}$', plate))

@app.route('/api/plates', methods=['POST'])
def store_plate():
    """
    Endpoint to store a vehicle plate.
    Expects a JSON body with a 'plate' key.
    """
    try:
        data = request.get_json(force=True)
        raw_plate = data.get('plate')
        if not raw_plate:
            logging.warning('No plate data provided')
            return jsonify({'status': 'error', 'message': 'No plate data provided'}), 400

        # Clean and validate the plate
        plate = raw_plate.strip().upper()
        if not is_valid_plate(plate):
            logging.warning('Invalid plate data provided: %s', plate)
            return jsonify({'status': 'error', 'message': 'Invalid plate data'}), 400

        # Thread-safe file access
        with file_lock:
            try:
                with open(PLATE_DATA_FILE, 'r') as file:
                    plates = json.load(file)
            except (IOError, json.JSONDecodeError) as e:
                logging.error(f'Error reading plate data: {str(e)}')
                return jsonify({'status': 'error', 'message': 'Error reading plate data'}), 500

            # Add the new plate if not already present
            if plate not in plates:
                plates.append(plate)
            else:
                logging.info('Plate %s already exists', plate)
                return jsonify({'status': 'success', 'message': f'Plate {plate} already exists'}), 200

            try:
                with open(PLATE_DATA_FILE, 'w') as file:
                    json.dump(plates, file)
            except IOError as e:
                logging.error(f'Error writing plate data: {str(e)}')
                return jsonify({'status': 'error', 'message': 'Error writing plate data'}), 500

        logging.info('Plate %s stored successfully', plate)
        return jsonify({'status': 'success', 'message': f'Plate {plate} stored successfully'}), 200

    except json.JSONDecodeError:
        logging.error('Error decoding JSON data')
        return jsonify({'status': 'error', 'message': 'Error decoding JSON data'}), 500
    except Exception as e:
        logging.error(f'Unexpected error: {str(e)}')
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/plates', methods=['GET'])
def get_plates():
    """
    Endpoint to retrieve all stored plates.
    """
    try:
        with file_lock:
            with open(PLATE_DATA_FILE, 'r') as file:
                plates = json.load(file)

        logging.info('Plates retrieved successfully')
        return jsonify({'status': 'success', 'data': plates}), 200

    except json.JSONDecodeError:
        logging.error('Error decoding JSON data')
        return jsonify({'status': 'error', 'message': 'Error decoding JSON data'}), 500
    except Exception as e:
        logging.error(f'Unexpected error: {str(e)}')
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/upload', methods=['POST'])
def upload_image():
    """
    Endpoint to process an uploaded image.
    It expects an image file with key 'file' in the multipart/form-data request.
    The image is processed (converted to grayscale) and returned as a base64 encoded PNG.
    """
    try:
        if 'file' not in request.files:
            logging.warning('No file part in the request')
            return jsonify({'status': 'error', 'message': 'No file part in the request'}), 400

        file = request.files['file']
        if file.filename == '':
            logging.warning('No selected file')
            return jsonify({'status': 'error', 'message': 'No selected file'}), 400

        # Validate file extension (basic check)
        allowed_extensions = {'png', 'jpg', 'jpeg', 'bmp'}
        ext = file.filename.rsplit('.', 1)[-1].lower()
        if ext not in allowed_extensions:
            logging.warning('Unsupported file type: %s', ext)
            return jsonify({'status': 'error', 'message': 'Unsupported file type'}), 400

        # Process the image using Pillow
        image = Image.open(file.stream)
        processed_image = image.convert('L')  # Convert to grayscale

        # Encode the processed image in base64
        img_byte_arr = io.BytesIO()
        processed_image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        encoded_image = base64.b64encode(img_byte_arr.read()).decode('utf-8')

        logging.info('Image processed successfully')
        return jsonify({
            'status': 'success',
            'message': 'Image processed successfully',
            'image': encoded_image
        }), 200

    except Exception as e:
        logging.error(f'Error processing image: {str(e)}')
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('PORT', 8000))
    app.run(debug=True, port=port)
