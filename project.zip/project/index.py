from flask import Flask, request, jsonify, render_template
import json
import os
import logging

app = Flask(__name__)

# Use environment variable for data file path
DATA_FILE = os.getenv('DATA_FILE', 'data.json')

# Set up logging
logging.basicConfig(level=logging.INFO)

def load_data():
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as file:
                return json.load(file)
    except json.JSONDecodeError as e:
        logging.error(f"Error decoding JSON: {e}")
    return []

def save_data(data):
    try:
        with open(DATA_FILE, 'w') as file:
            json.dump(data, file, indent=4)
    except IOError as e:
        logging.error(f"Error writing to file: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_entry', methods=['POST'])
def add_entry():
    data = request.json
    required_keys = {'busName', 'numberPlate', 'from', 'to', 'platformNumber'}
    
    if not data or not required_keys.issubset(data.keys()):
        return jsonify({'error': 'Missing or invalid data'}), 400

    entries = load_data()
    entries.append(data)
    save_data(entries)
    return jsonify({'message': 'Entry added successfully'}), 200

@app.route('/get_entries', methods=['GET'])
def get_entries():
    entries = load_data()
    return jsonify(entries), 200

@app.route('/clear_draft', methods=['POST'])
def clear_draft():
    # Implement draft clearing logic if needed
    return jsonify({'message': 'Draft cleared'}), 200

if __name__ == '__main__':
    app.run(debug=True) 