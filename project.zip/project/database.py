import os
import datetime
import json
import logging
from functools import wraps
from typing import Dict, Any

from flask import Flask, request, jsonify, send_from_directory, Blueprint, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import jwt
import bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from google.oauth2 import id_token
from google.auth.transport import requests as google_requests

# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    # Use one SQLite file for everything
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URI', 'sqlite:///app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit
    JSONIFY_PRETTYPRINT_REGULAR = True

# ------------------------------------------------------------------
# Logging Configuration
# ------------------------------------------------------------------
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Ensure the upload folder exists
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

# ------------------------------------------------------------------
# Flask App Setup
# ------------------------------------------------------------------
app = Flask(__name__)
app.config.from_object(Config)
CORS(app, resources={r"/api/*": {"origins": "*"}})
db = SQLAlchemy(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"])

# Create a blueprint for API endpoints
api_bp = Blueprint('api', __name__, url_prefix='/api')

# ------------------------------------------------------------------
# Database Models
# ------------------------------------------------------------------
# User model for profile and authentication
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    dob = db.Column(db.String(20), nullable=True)  # stored as string for simplicity
    state = db.Column(db.String(50), nullable=True)
    profile_photo = db.Column(db.String(200), nullable=True)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    # One-to-many: A user can have multiple posts
    posts = db.relationship('Post', backref='author', lazy=True)

# Optional Post model (if you need user posts)
class Post(db.Model):
    __tablename__ = 'posts'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

# Vehicle model for vehicle monitoring data
class Vehicle(db.Model):
    __tablename__ = 'vehicles'
    id = db.Column(db.Integer, primary_key=True)
    bus_name = db.Column(db.String(100), nullable=False)
    number_plate = db.Column(db.String(20), nullable=False)
    from_location = db.Column(db.String(100), nullable=False)
    to_location = db.Column(db.String(100), nullable=False)
    platform_number = db.Column(db.String(50), nullable=False)
    bus_stand = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# Plate model for scanned plate numbers (from camera functionality)
class Plate(db.Model):
    __tablename__ = 'plates'
    id = db.Column(db.Integer, primary_key=True)
    plate = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# ------------------------------------------------------------------
# Static Data for States and Bus Stand Details
# ------------------------------------------------------------------
stateData = {
    "tamil_nadu": {
        "districts": {
            "chennai": {"busStands": ["Chennai Mofussil Bus Terminus (CMBT)", "Koyambedu Bus Stand"]},
            "coimbatore": {"busStands": ["Gandhipuram Central Bus Stand", "Ukkadam Bus Stand"]},
            "madurai": {"busStands": ["Mattuthavani Bus Stand", "Periyar Bus Stand"]},
            "salem": {"busStands": ["Salem Central Bus Stand"]},
            "trichy": {"busStands": ["Central Bus Stand", "Chathiram Bus Stand"]}
        }
    },
    "kerala": {
        "districts": {
            "thiruvananthapuram": {"busStands": ["Thampanoor Bus Stand"]},
            "kochi": {"busStands": ["Vyttila Mobility Hub", "Ernakulam KSRTC Bus Stand"]},
            "calicut": {"busStands": ["Moffusil Bus Stand"]},
            "kollam": {"busStands": ["Kollam KSRTC Bus Stand"]}
        }
    },
    "karnataka": {
        "districts": {
            "bangalore": {"busStands": ["Kempegowda Bus Station", "Shantinagar Bus Stand"]},
            "mysore": {"busStands": ["Mysore City Bus Stand"]},
            "mangalore": {"busStands": ["State Bank Bus Stand"]},
            "hubli": {"busStands": ["Old Bus Stand"]}
        }
    }
}

busStandDetails = {
    "Chennai Mofussil Bus Terminus (CMBT)": {
        "address": "Koyambedu, Chennai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Chennai+Mofussil+Bus+Terminus"
    },
    "Koyambedu Bus Stand": {
        "address": "Koyambedu, Chennai, Tamil Nadu, India",
        "operatingHours": "24 Hours",
        "facilities": "Shops, food stalls, restrooms",
        "mapLink": "https://maps.google.com/?q=Koyambedu+Bus+Stand"
    },
    # Additional details for other bus stands...
}

# ------------------------------------------------------------------
# Helper Functions for API
# ------------------------------------------------------------------
def generate_jwt(user_id: int) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1),
        'iat': datetime.datetime.utcnow(),
        'nbf': datetime.datetime.utcnow(),
        'iss': 'app'
    }
    token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm="HS256")
    if isinstance(token, bytes):
        token = token.decode('utf-8')
    return token

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            logger.debug("Authorization header missing")
            return jsonify({'error': 'Token is missing'}), 401
        token_parts = auth_header.split()
        token = token_parts[1] if len(token_parts) == 2 and token_parts[0].lower() == "bearer" else auth_header
        try:
            data: Dict[str, Any] = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(data.get('user_id'))
            if not current_user:
                logger.debug("User not found for token")
                return jsonify({'error': 'User not found'}), 401
        except jwt.ExpiredSignatureError:
            logger.debug("Token expired")
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError as err:
            logger.exception("Invalid token: %s", err)
            return jsonify({'error': 'Token is invalid'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

def vehicle_to_dict(vehicle: Vehicle) -> Dict[str, Any]:
    return {
        'id': vehicle.id,
        'busName': vehicle.bus_name,
        'numberPlate': vehicle.number_plate,
        'from': vehicle.from_location,
        'to': vehicle.to_location,
        'platformNumber': vehicle.platform_number,
        'busStand': vehicle.bus_stand,
        'createdAt': vehicle.created_at.isoformat()
    }

def plate_to_dict(plate: Plate) -> Dict[str, Any]:
    return {
        'id': plate.id,
        'plate': plate.plate,
        'createdAt': plate.created_at.isoformat()
    }

# ------------------------------------------------------------------
# API Endpoints
# ------------------------------------------------------------------

# ----- User Endpoints -----
@api_bp.route('/register', methods=['POST'])
@limiter.limit("5 per minute")
def register():
    try:
        if request.content_type and request.content_type.startswith('multipart/form-data'):
            data = request.form
            profile_photo_file = request.files.get('profilePhoto')
        else:
            data = request.get_json(silent=True) or {}
            profile_photo_file = None

        required_fields = ['email', 'fullName', 'password']
        missing = [field for field in required_fields if not data.get(field)]
        if missing:
            msg = f"Missing required fields: {', '.join(missing)}"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        email = data.get('email')
        if User.query.filter_by(email=email).first():
            msg = "Email already registered"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        profile_photo_url = None
        if profile_photo_file:
            filename = secure_filename(profile_photo_file.filename)
            if not filename:
                msg = "Invalid file name for profile photo."
                logger.debug(msg)
                return jsonify({'error': msg}), 400
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            profile_photo_file.save(file_path)
            profile_photo_url = f"/api/uploads/{filename}"
            logger.debug(f"Profile photo saved: {file_path}")

        password_hash = bcrypt.hashpw(data.get('password').encode('utf-8'), bcrypt.gensalt())

        new_user = User(
            full_name=data.get('fullName'),
            email=email,
            phone=data.get('phone'),
            dob=data.get('dob'),
            state=data.get('state'),
            profile_photo=profile_photo_url,
            password_hash=password_hash.decode('utf-8')
        )
        db.session.add(new_user)
        db.session.commit()
        logger.info(f"User registered: {email}")
        return jsonify({
            'message': 'Registration successful',
            'user': {
                'id': new_user.id,
                'fullName': new_user.full_name,
                'email': new_user.email,
                'phone': new_user.phone,
                'dob': new_user.dob,
                'state': new_user.state,
                'profilePhoto': new_user.profile_photo
            }
        }), 201

    except Exception as e:
        db.session.rollback()
        logger.exception("Registration failed: %s", e)
        return jsonify({'error': f'An error occurred during registration: {str(e)}'}), 500

@api_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    try:
        data = request.get_json(silent=True) or {}
        if not data.get('email') or not data.get('password'):
            msg = "Missing email or password"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        user = User.query.filter_by(email=data.get('email')).first()
        if not user:
            msg = "User does not exist"
            logger.debug(msg)
            return jsonify({'error': msg}), 401

        if not bcrypt.checkpw(data.get('password').encode('utf-8'), user.password_hash.encode('utf-8')):
            msg = "Invalid password"
            logger.debug(msg)
            return jsonify({'error': msg}), 401

        token = generate_jwt(user.id)
        logger.info(f"User logged in: {user.email}")
        return jsonify({
            'token': token,
            'user': {
                'id': user.id,
                'fullName': user.full_name,
                'email': user.email,
                'phone': user.phone,
                'dob': user.dob,
                'state': user.state,
                'profilePhoto': user.profile_photo
            }
        })

    except Exception as e:
        logger.exception("Login failed: %s", e)
        return jsonify({'error': f'An error occurred during login: {str(e)}'}), 500

@api_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    return jsonify({
        'id': current_user.id,
        'fullName': current_user.full_name,
        'email': current_user.email,
        'phone': current_user.phone,
        'dob': current_user.dob,
        'state': current_user.state,
        'profilePhoto': current_user.profile_photo,
        'createdAt': current_user.created_at.isoformat()
    })

@api_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    try:
        data = request.get_json(silent=True) or {}
        updated_fields = []
        if 'fullName' in data:
            current_user.full_name = data['fullName']
            updated_fields.append('fullName')
        if 'phone' in data:
            current_user.phone = data['phone']
            updated_fields.append('phone')
        if 'dob' in data:
            current_user.dob = data['dob']
            updated_fields.append('dob')
        if 'state' in data:
            current_user.state = data['state']
            updated_fields.append('state')
        if not updated_fields:
            msg = "No valid fields to update"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        db.session.commit()
        logger.info(f"User updated: {current_user.email} (fields: {', '.join(updated_fields)})")
        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': current_user.id,
                'fullName': current_user.full_name,
                'email': current_user.email,
                'phone': current_user.phone,
                'dob': current_user.dob,
                'state': current_user.state,
                'profilePhoto': current_user.profile_photo
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        logger.exception("Profile update failed: %s", e)
        return jsonify({'error': f'Could not update profile: {str(e)}'}), 500

# ----- Vehicle Endpoints -----
@api_bp.route('/vehicles', methods=['GET'])
@limiter.limit("20 per minute")
def get_vehicles():
    try:
        bus_stand_filter = request.args.get('busStand', None)
        query = Vehicle.query
        if bus_stand_filter:
            query = query.filter(Vehicle.bus_stand == bus_stand_filter)
        vehicles = query.order_by(Vehicle.created_at.desc()).all()
        return jsonify({'vehicles': [vehicle_to_dict(v) for v in vehicles]}), 200
    except Exception as e:
        logger.exception("Error retrieving vehicles: %s", e)
        return jsonify({'error': f'Error retrieving vehicles: {str(e)}'}), 500

@api_bp.route('/vehicles', methods=['POST'])
@limiter.limit("10 per minute")
def add_vehicle():
    try:
        data = request.get_json(silent=True) or {}
        required_fields = ['busName', 'numberPlate', 'from', 'to', 'platformNumber', 'busStand']
        missing = [field for field in required_fields if not data.get(field)]
        if missing:
            msg = f"Missing required fields: {', '.join(missing)}"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        new_vehicle = Vehicle(
            bus_name=data.get('busName'),
            number_plate=data.get('numberPlate'),
            from_location=data.get('from'),
            to_location=data.get('to'),
            platform_number=data.get('platformNumber'),
            bus_stand=data.get('busStand')
        )
        db.session.add(new_vehicle)
        db.session.commit()
        logger.info(f"New vehicle added: {new_vehicle.number_plate}")
        return jsonify({'message': 'Vehicle added successfully', 'vehicle': vehicle_to_dict(new_vehicle)}), 201

    except Exception as e:
        db.session.rollback()
        logger.exception("Error adding vehicle: %s", e)
        return jsonify({'error': f'Error adding vehicle: {str(e)}'}), 500

@api_bp.route('/vehicles/<int:vehicle_id>', methods=['GET'])
@limiter.limit("20 per minute")
def get_vehicle(vehicle_id):
    try:
        vehicle = Vehicle.query.get(vehicle_id)
        if not vehicle:
            return jsonify({'error': 'Vehicle not found'}), 404
        return jsonify({'vehicle': vehicle_to_dict(vehicle)}), 200
    except Exception as e:
        logger.exception("Error retrieving vehicle: %s", e)
        return jsonify({'error': f'Error retrieving vehicle: {str(e)}'}), 500

# ----- Plate Endpoints -----
@api_bp.route('/plates', methods=['POST'])
@limiter.limit("10 per minute")
def store_plate():
    try:
        data = request.get_json(silent=True) or {}
        plate_text = data.get('plate')
        if not plate_text:
            logger.debug("No plate provided")
            return jsonify({'error': 'No plate provided'}), 400

        # Simple validation for alphanumeric up to 10 chars
        if not isinstance(plate_text, str) or not plate_text.isalnum() or len(plate_text) > 10:
            logger.debug("Invalid plate format")
            return jsonify({'error': 'Invalid plate data'}), 400

        new_plate = Plate(plate=plate_text)
        db.session.add(new_plate)
        db.session.commit()
        logger.info(f"Plate {plate_text} stored successfully")
        return jsonify({'message': f'Plate {plate_text} stored successfully', 'plate': plate_to_dict(new_plate)}), 200

    except Exception as e:
        db.session.rollback()
        logger.exception("Error storing plate: %s", e)
        return jsonify({'error': f'Error storing plate: {str(e)}'}), 500

@api_bp.route('/plates', methods=['GET'])
@limiter.limit("20 per minute")
def get_plates():
    try:
        plates = Plate.query.order_by(Plate.created_at.desc()).all()
        return jsonify({'plates': [plate_to_dict(p) for p in plates]}), 200
    except Exception as e:
        logger.exception("Error retrieving plates: %s", e)
        return jsonify({'error': f'Error retrieving plates: {str(e)}'}), 500

# ----- Static Data Endpoints -----
@api_bp.route('/states', methods=['GET'])
def get_states():
    try:
        return jsonify({'states': stateData}), 200
    except Exception as e:
        logger.exception("Error retrieving states data: %s", e)
        return jsonify({'error': f'Error retrieving states data: {str(e)}'}), 500

@api_bp.route('/bus-stand-details', methods=['GET'])
def get_bus_stand_details():
    try:
        bus_stand_name = request.args.get('name', None)
        if not bus_stand_name:
            return jsonify({'error': 'Bus stand name not provided'}), 400
        details = busStandDetails.get(bus_stand_name)
        if not details:
            return jsonify({'error': 'Bus stand details not found'}), 404
        return jsonify({'busStandDetails': details}), 200
    except Exception as e:
        logger.exception("Error retrieving bus stand details: %s", e)
        return jsonify({'error': f'Error retrieving bus stand details: {str(e)}'}), 500

# ----- File Serving Endpoint -----
@api_bp.route('/uploads/<filename>')
def uploaded_file(filename):
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    except Exception as e:
        logger.exception("Error serving file: %s", e)
        return jsonify({'error': f'Error serving file: {str(e)}'}), 500

# ------------------------------------------------------------------
# Register Blueprint and Initialize DB
# ------------------------------------------------------------------
app.register_blueprint(api_bp)

def init_db():
    with app.app_context():
        db.create_all()
        logger.info("Database initialized")

# Global error handler for unhandled exceptions
@app.errorhandler(Exception)
def handle_exception(e):
    logger.exception("Unhandled exception: %s", e)
    return jsonify({'error': f'An internal error occurred: {str(e)}'}), 500

# ------------------------------------------------------------------
# Run Application
# ------------------------------------------------------------------
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8000, debug=True)
