import os
import datetime
import logging
from functools import wraps
from typing import Dict, Any

from flask import Flask, request, jsonify, send_from_directory, Blueprint
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import jwt
import bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-here')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URI', 'sqlite:///users.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit
    JSONIFY_PRETTYPRINT_REGULAR = True

# ------------------------------------------------------------------
# Logging Configuration
# ------------------------------------------------------------------
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Ensure the upload folder exists
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

# ------------------------------------------------------------------
# Flask App Setup
# ------------------------------------------------------------------
app = Flask(__name__)
app.config.from_object(Config)
CORS(app, resources={r"/api/*": {"origins": "*"}})
db = SQLAlchemy(app)

# Initialize rate limiter
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"])

# Create a Blueprint for profile-related API endpoints
profile_bp = Blueprint('profile', __name__, url_prefix='/api')

# ------------------------------------------------------------------
# Models
# ------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    dob = db.Column(db.String(20), nullable=True)  # stored as string for simplicity
    state = db.Column(db.String(50), nullable=True)
    profile_photo = db.Column(db.String(200), nullable=True)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# ------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------
def generate_jwt(user_id: int) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1),
        'iat': datetime.datetime.utcnow(),
        'nbf': datetime.datetime.utcnow(),
        'iss': 'profile-app'
    }
    token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm="HS256")
    if isinstance(token, bytes):
        token = token.decode('utf-8')
    return token

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            logger.debug("Missing Authorization header.")
            return jsonify({'error': 'Token is missing'}), 401

        token_parts = auth_header.split()
        token = token_parts[1] if len(token_parts) == 2 and token_parts[0].lower() == "bearer" else auth_header
        try:
            data: Dict[str, Any] = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(data.get('user_id'))
            if not current_user:
                logger.debug("User not found for given token data.")
                return jsonify({'error': 'User not found'}), 401
        except jwt.ExpiredSignatureError:
            logger.debug("Token has expired.")
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError as err:
            logger.exception("Invalid token: %s", err)
            return jsonify({'error': 'Token is invalid'}), 401
        return f(current_user, *args, **kwargs)
    return decorated

# ------------------------------------------------------------------
# API Endpoints
# ------------------------------------------------------------------

# User Registration
@profile_bp.route('/register', methods=['POST'])
@limiter.limit("5 per minute")
def register():
    try:
        # Support JSON and multipart/form-data requests
        if request.content_type and request.content_type.startswith('multipart/form-data'):
            data = request.form
            profile_photo_file = request.files.get('profilePhoto')
        else:
            data = request.get_json(silent=True) or {}
            profile_photo_file = None

        required_fields = ['email', 'fullName', 'password']
        missing = [field for field in required_fields if not data.get(field)]
        if missing:
            msg = f"Missing required fields: {', '.join(missing)}"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        email = data.get('email')
        if User.query.filter_by(email=email).first():
            msg = "Email already registered"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        profile_photo_url = None
        if profile_photo_file:
            filename = secure_filename(profile_photo_file.filename)
            if not filename:
                msg = "Invalid file name for profile photo."
                logger.debug(msg)
                return jsonify({'error': msg}), 400
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            profile_photo_file.save(file_path)
            profile_photo_url = f"/api/uploads/{filename}"
            logger.debug(f"Profile photo saved: {file_path}")

        password_hash = bcrypt.hashpw(data.get('password').encode('utf-8'), bcrypt.gensalt())

        new_user = User(
            full_name=data.get('fullName'),
            email=email,
            phone=data.get('phone'),
            dob=data.get('dob'),
            state=data.get('state'),
            profile_photo=profile_photo_url,
            password_hash=password_hash.decode('utf-8')
        )
        db.session.add(new_user)
        db.session.commit()

        logger.info(f"User registered: {email}")
        return jsonify({
            'message': 'Registration successful',
            'user': {
                'id': new_user.id,
                'fullName': new_user.full_name,
                'email': new_user.email,
                'phone': new_user.phone,
                'dob': new_user.dob,
                'state': new_user.state,
                'profilePhoto': new_user.profile_photo
            }
        }), 201

    except Exception as e:
        db.session.rollback()
        logger.exception("Registration failed: %s", e)
        return jsonify({'error': f'An error occurred during registration: {str(e)}'}), 500

# User Login
@profile_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    try:
        data = request.get_json(silent=True) or {}
        if not data.get('email') or not data.get('password'):
            msg = "Missing email or password"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        user = User.query.filter_by(email=data.get('email')).first()
        if not user:
            msg = "User does not exist"
            logger.debug(msg)
            return jsonify({'error': msg}), 401

        if not bcrypt.checkpw(data.get('password').encode('utf-8'), user.password_hash.encode('utf-8')):
            msg = "Invalid password"
            logger.debug(msg)
            return jsonify({'error': msg}), 401

        token = generate_jwt(user.id)
        logger.info(f"User logged in: {user.email}")
        return jsonify({
            'token': token,
            'user': {
                'id': user.id,
                'fullName': user.full_name,
                'email': user.email,
                'phone': user.phone,
                'dob': user.dob,
                'state': user.state,
                'profilePhoto': user.profile_photo
            }
        })

    except Exception as e:
        logger.exception("Login failed: %s", e)
        return jsonify({'error': f'An error occurred during login: {str(e)}'}), 500

# Get Current User Profile
@profile_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    return jsonify({
        'id': current_user.id,
        'fullName': current_user.full_name,
        'email': current_user.email,
        'phone': current_user.phone,
        'dob': current_user.dob,
        'state': current_user.state,
        'profilePhoto': current_user.profile_photo,
        'createdAt': current_user.created_at.isoformat()
    })

# Update User Profile
@profile_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    try:
        data = request.get_json(silent=True) or {}
        updated_fields = []
        if 'fullName' in data:
            current_user.full_name = data['fullName']
            updated_fields.append('fullName')
        if 'phone' in data:
            current_user.phone = data['phone']
            updated_fields.append('phone')
        if 'dob' in data:
            current_user.dob = data['dob']
            updated_fields.append('dob')
        if 'state' in data:
            current_user.state = data['state']
            updated_fields.append('state')

        if not updated_fields:
            msg = "No valid fields to update"
            logger.debug(msg)
            return jsonify({'error': msg}), 400

        db.session.commit()
        logger.info(f"User updated: {current_user.email} (fields: {', '.join(updated_fields)})")
        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': current_user.id,
                'fullName': current_user.full_name,
                'email': current_user.email,
                'phone': current_user.phone,
                'dob': current_user.dob,
                'state': current_user.state,
                'profilePhoto': current_user.profile_photo
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        logger.exception("Profile update failed: %s", e)
        return jsonify({'error': f'Could not update profile: {str(e)}'}), 500

# Serve Uploaded Files (e.g., Profile Photos)
@profile_bp.route('/uploads/<filename>')
def uploaded_file(filename):
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    except Exception as e:
        logger.exception("Error serving file: %s", e)
        return jsonify({'error': f'Error serving file: {str(e)}'}), 500

# ------------------------------------------------------------------
# Register Blueprint and Initialize DB
# ------------------------------------------------------------------
app.register_blueprint(profile_bp)

def init_db():
    with app.app_context():
        db.create_all()
        logger.info("Database initialized")

# Global error handler
@app.errorhandler(Exception)
def handle_exception(e):
    logger.exception("Unhandled exception: %s", e)
    return jsonify({'error': f'An internal error occurred: {str(e)}'}), 500

# ------------------------------------------------------------------
# Run Application
# ------------------------------------------------------------------
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8000, debug=True)
